import carpeta_modulos.vehiculos as vehiculo

auto_1 = vehiculo.Auto("Audi", "A4", 50, "Azul espacial", 4)
print(auto_1)
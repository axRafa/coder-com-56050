from setuptools import setup

setup(
    name = "paquete_segunda_pre-entrega",
    version = "1.0",
    description = "Paquete Distribuido",
    author = "Curso-Python",
    autor_email = "cosme_fulanito@hotmail.com",
    packages = ["carpeta_modulos"]
)